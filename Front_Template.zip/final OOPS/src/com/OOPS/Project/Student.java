package com.OOPS.Project;

import java.io.*;
import java.util.ArrayList;


public class Student {
    private String name;
    private String rollNo;
    private ArrayList<Course> courses = new ArrayList<Course>();
    private static ArrayList<Student> students = new ArrayList<Student>();
    public static String month;

    Student(String rollNo, String name) {
        this.name = name;
        this.rollNo = rollNo;
    }

    public static void updateAttendanceFile(ArrayList<Student> students, String month) {
        try {
            Student.month = month;
            BufferedWriter csv = new BufferedWriter(new FileWriter("csv files/Attendance - " + month +  ".csv"));
            csv.write(month + " 2020,,");
            ArrayList<Course> courses = Course.getCourses();
            for(int i = 0; i < courses.size(); i++) {
                csv.write(courses.get(i).getCode() + " - " + courses.get(i).getName() + ",,,,,");
            }
            csv.newLine();
            csv.write(",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
            csv.newLine();
            csv.write(",,");
            for(int i = 0; i < courses.size(); i++) {
                csv.write("Present,,Late,Excused absence,Unexcused Absence,");
            }
            csv.newLine();
            csv.write("Roll No., Student Name,");
            for(int i = 0; i < courses.size(); i++) {
                csv.write("P,%,L,E,U,");
            }
            csv.newLine();
            for(int i = 0; i < students.size(); i++) {
                Student s = students.get(i);
                csv.write(s.getRollNo()+ "," + s.getName()+",");
                int j = 0;
                int breaker = 3;
                if(month.equals("August")) {
                    breaker = 4;
                }
                for (int k = 2; k < 38; k = k + breaker) {
                    Course course = s.courses.get(j);
                    //Course course = Course.getCourses().get(j);

                    csv.write("" + course.getPresentHr() + ",");
                    double percentage = (course.getPresentHr() * 100.0 )/ Course.totalhourAug[j];
                    csv.write("" + percentage + ",");
                    csv.write("" + course.getAbsentHr() + ",");
                    csv.write("" + course.getExcusedHr() + ",");
                    csv.write("" + course.getUnexcusedHr() + ",");
                    k++;
                    j++;
                }
                csv.newLine();
            }
            csv.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        readAttendance(month);
    }


    public static void readAttendance(String month) {
        students.removeAll(students);

        Student.month = month;
        System.out.println();
        System.out.println(month);
        System.out.println();
        String csvSplit = ",";
        try {
            BufferedReader csv = new BufferedReader(new FileReader("csv files/Attendance - " + month +  ".csv"));
            String line;
            csv.readLine();
            csv.readLine();
            csv.readLine();
            csv.readLine();
            while ((line = csv.readLine()) != null) {
                Student s = new Student();
                String[] sub = line.split(csvSplit);
                s.rollNo = sub[0];
                s.name = sub[1];
                int j = 0;
                int breaker = 3;
                if(month.equals("August")) {
                    breaker = 4;
                }
                ArrayList<Course> courses = new ArrayList<Course>();
                for (int i = 2; i < 38; i = i + breaker) {
                    Course course = new Course(j);
                    course.setPresentHr(Integer.parseInt(sub[i]));
                    double d = Double.parseDouble(sub[i + 1]);
                    d =(double) Math.round(d  * 100.0) / 100.0;
                    course.setPercentage(d);
                    course.setAbsentHr(Integer.parseInt(sub[i + 2]));
                    course.setExcusedHr(Integer.parseInt(sub[i + 3]));
                    course.setUnexcusedHr(Integer.parseInt(sub[i + 4]));
                    i++;
                    j++;
                    courses.add(course);
                }
                s.setCourses(courses);
                students.add(s);
            }
            csv.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        viewAttendanceStudent(students);
    }

    public static void viewAttendanceStudent(ArrayList<Student> students) {
        System.out.println("Name Roll no");
        for(int i = 0; i < students.size(); i++) {
            Student s = students.get(i);
            ArrayList<Course> c = s.getCourses();
            System.out.println(s.getName() + " " + s.getRollNo() );

            for (int j = 0; j < c.size(); j++) {
                System.out.print(c.get(j).getName());
                System.out.print("  Present: " + c.get(j).getPresentHr());
                System.out.print("  Absent: " + c.get(j).getAbsentHr());
                System.out.print("  Excused: " + c.get(j).getExcusedHr());
                System.out.print("  Unexcused: " + c.get(j).getUnexcusedHr());
                System.out.printf("%.2f", c.get(j).getPercentage());
                System.out.println();
            }
            System.out.println();
        }
    }

    public static boolean validateIas (String rollNo) {
        String sub = rollNo.substring(0, 6);
        int last_d = Integer.parseInt(rollNo.substring(6));
        System.out.println(sub + " " + last_d);
        return sub.equals("19IZUS") && last_d >= 9 && last_d <= 17;
    }

    class InvalidRollNoException extends Exception{
        String warning;
        InvalidRollNoException(String w) {
            warning=w;
        }
        public String toString() {
            return  "InvalidRollNoException: "+warning;
        }
    }


    Student() {
        super();
        this.courses = Course.getCourses();
    }

    Student(String RollNo) {
        this.rollNo = RollNo;
    }
    public static ArrayList<Student> getStudents() {
        return students;
    }

    public static void setStudents(ArrayList<Student> students) {
        Student.students = students;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public void setCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    public static String[] getNames() {
        int n = Student.getStudents().size();
        String[] str = new String[n];
        for(int i = 0; i < n; i++) {
            str[i] = Student.getStudents().get(i).getName();
        }
        return str;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                '}';
    }
}