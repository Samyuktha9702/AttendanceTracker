package com.OOPS.Project;

import java.io.*;
import java.util.ArrayList;

public class Course {
    private String code;
    private String name;
    private String staff;
    private int presentHr;
    private int absentHr;
    private int excusedHr;
    private int unexcusedHr;
    private double percentage;
    private static ArrayList<Course> courses = new ArrayList<Course>();
    private static final String filepath = "csv files/Courses.csv";
    public static int[] totalhourAug={7,6,8,9,6,6,6,4,3};
    public static int[] totalhoursOct = {13, 8, 8, 0, 10, 0, 10, 8, 0};
    public static int[] totalhourSep = {12, 10, 8, 14, 6, 8 , 8 ,10, 3};

    public Course(int i) {
        this.name = courses.get(i).getName();
    }

    public Course() {
        readCoursesFromFile();

    }

    public static void readCoursesFromFile() { //returns the array of courses
        try {
            BufferedReader br = new BufferedReader(new FileReader("csv files/Attendance1.csv"));
            BufferedWriter out = new BufferedWriter(new FileWriter("csv files/Courses.csv")); // create Courses.csv file for courses
            
            String line = br.readLine();
            
            String splitBy = ",";
            String[] sub = line.split(splitBy);
            
            String code, name;
            
            for (int i = 1; i < sub.length; i++) {
                if (!sub[i].isEmpty()) {
                    String[] c = sub[i].split("-");
                    code = c[0].trim();
                    c[1] = c[1].replace("+", " ");
                    name = c[1].trim();

                    out.write(code + ", " + name); //write to Courses.csv file
                    out.newLine();
                    Course cse = new Course(code, name);
                    courses.add(cse);
                }
            }
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    Course(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static ArrayList<Course> getCourses() {
        return courses;
    }

    public int getPresentHr() {
        return presentHr;
    }

    public void setPresentHr(int presentHr) {
        this.presentHr = presentHr;
    }

    public int getAbsentHr() {
        return absentHr;
    }

    public void setAbsentHr(int absentHr) {
        this.absentHr = absentHr;
    }

    public int getExcusedHr() {
        return excusedHr;
    }

    public void setExcusedHr(int excusedHr) {
        this.excusedHr = excusedHr;
    }

    public int getUnexcusedHr() {
        return unexcusedHr;
    }

    public void setUnexcusedHr(int unexcusedHr) {
        this.unexcusedHr = unexcusedHr;
    }

    public double getPercentage() {
        return (this.presentHr * 100.0) / 7;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }
}