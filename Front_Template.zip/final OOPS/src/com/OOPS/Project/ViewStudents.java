package com.OOPS.Project;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewStudents extends JFrame {
    private JComboBox courseCombo;
    private JList list1; // = new JList(Student.studentToString());
    private JTextField name;
    private JTextField rollNo;
    private JTextField absent;
    private JTextField excusedAbsence;
    private JTextField unexcusedAbsence;
    private JTextField percentage;
    private JTextField present;
    private JPanel mainPanel;
    private JScrollPane scrollPanel;
    private int courseIndex = 0;
    private int studentIndex = 0;
    private String month;

    ViewStudents(String month, int studentNo) {
        super("View All Students");
        this.setContentPane(this.mainPanel);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.pack();

        this.studentIndex = studentNo;
        list1.setSelectedIndex(studentIndex);


        for(int i = 0; i < Course.getCourses().size(); i++) {
            String str = Course.getCourses().get(i).getName();
            courseCombo.addItem(str);
        }
        courseCombo.setSelectedIndex(courseIndex);
        displayStudent(studentIndex, courseIndex);

        courseCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                courseIndex = courseCombo.getSelectedIndex();
                displayStudent(studentIndex, courseIndex);
            }
        });

        list1.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                JList list1 = (JList) e.getSource();
                studentIndex = (int) list1.getSelectedIndex();
                displayStudent(studentIndex, courseIndex);
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
        list1 = new JList(Student.getNames());
        //list1.setSelectedIndex();
        scrollPanel = new JScrollPane(list1);

    }

    public void displayStudent(int studentIndex, int courseIndex) {
        Student s = Student.getStudents().get(studentIndex);
        name.setText(s.getName());
        rollNo.setText(s.getRollNo());
        present.setText(Integer.toString(s.getCourses().get(courseIndex).getPresentHr()));
        absent.setText(Integer.toString(s.getCourses().get(courseIndex).getAbsentHr()));
        excusedAbsence.setText(Integer.toString(s.getCourses().get(courseIndex).getExcusedHr()));
        unexcusedAbsence.setText(Integer.toString(s.getCourses().get(courseIndex).getUnexcusedHr()));
        percentage.setText(Double.toString(s.getCourses().get(courseIndex).getPercentage()));
    }
}
