package com.OOPS.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class adminLogin extends JFrame {
    private JButton viewStudentsButton;
    private JPanel mainPanel;
    private JButton EditButton;
    private JButton viewAllStudentsButton;
    private JComboBox monthCombo;

    public adminLogin() {
        super("Admin Login");
        this.setContentPane(this.mainPanel);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);


        String[] month = {"August", "September", "October"};
        for (int i = 0; i < month.length; i++) {
            String str = month[i];
            monthCombo.addItem(str);
        }
        monthCombo.setSelectedIndex(0);

        String m = month[monthCombo.getSelectedIndex()];
        Course.readCoursesFromFile();
        Student.readAttendance(m);

        this.pack();



        EditButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new EditStudents(m, 0).setVisible(true);
            }
        });

        viewAllStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new ViewStudents(m, 0).setVisible(true);
            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
