package com.OOPS.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EntryPortal extends JFrame{
    private JPanel JPanelTop;
    private JPanel JPanelMiddle;
    private JPanel JPanelBottom;
    private JButton adminButton;
    private JButton staffButton;
    private JButton studentButton;
    private JPanel JPanelSelectRole;
    private JPanel mainPanel;

    public EntryPortal(){
        super("Entry portal");
        this.setContentPane(this.mainPanel);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        this.pack();

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new adminLogin().setVisible(true);
            }
        });

    }
    public static void main(String[] args) {
        EntryPortal entry = new EntryPortal();
        entry.setVisible(true);

    }

}
