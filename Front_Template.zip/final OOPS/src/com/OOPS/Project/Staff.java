package com.OOPS.Project;

public class Staff extends Course {
    private String name;

    Staff() {
        super();
    }

    public static boolean validateStaff(String str)
    {
        String sub=str.substring(0,4);
        String last_digits=str.substring(4);
        int last_d=Integer.parseInt(last_digits);
        if(sub.equals("19Z3")  && (last_d>=1 && last_d<=12)) {
            return true;
        }
        else {
            return false;
        }
    }

    public static boolean validateReg(String r) {
        String sub = r.substring(0, 4);
        String last_digits = r.substring(4);
        int last_d = Integer.parseInt(last_digits);
        if (sub.equals("19Z3") && (last_d >= 1 && last_d <= 64) && last_d != 19 && last_d != 25) {
            return true;
        } else {
            return false;
        }
    }

}